<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'zakasshop';
$config['googleplus']['client_id']        = '919003826401-30pqfmpnii1p6fu05jgk79noavgurgen.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'vo4Vm3ajoi_LWKnn9IgggNpr';
$config['googleplus']['redirect_uri']     = 'http://www.aadiindustries.co/zakasshop/loginWithGooglePlus';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

