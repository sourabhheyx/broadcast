 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {
/*
| 1. 
| 2. login - show login page of website
| 3. forgot_password - show forgot page of website
| 4. 
| 5.    
| 6. 
|
*/
	function __construct(){
		parent::__construct();
        $this->load->model('Adminmodel','adminmodel');
        date_default_timezone_set("Asia/Kolkata"); 
        header('Content-type: text/json');
	}
	
//----------------------------Login Api---------------------------------------------//	

  public function schedule_brodcast(){
    
       
       
        $userdata = $this->adminmodel->getwhere('send_schedule',array('status'=>0));
        
        if(!empty($userdata))
        {
            foreach($userdata as $keys =>$val)
            {   
                if(strtotime(date("Y-m-d H:i", strtotime($val['schedule_date_time']))) <= strtotime(date("Y-m-d H:i"))){
                $user = $this->adminmodel->getwheres('users',array('user_id'=>$val['created_by']));
                if(!empty($user['dsix_api_key'])){
                 $this->send_massages($val['data_ress'],$user['dsix_api_key']);
                }
                
                $this->adminmodel->update_data('send_schedule',array('id'=>$val['id']),array('send_date_time'=>date("Y-m-d H:i:s"),'status'=>1));
                }
            }
        }
        
        $data["responce"] = true;
        $data["massage"] = $userdata; 
  		        
      
      
       echo json_encode($data); 
          
    }
    
    
    public function get_templates($apikey)
   {
       
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://waba.360dialog.io/v1/configs/templates",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "d360-api-key: $apikey",
            "postman-token: acb3bf60-e93e-a937-c5a6-0d489d2accb4"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          return "cURL Error #:" . $err;
        } else {
          return $response;
        }
   }
   
   public function verify_con($contact,$apikey)
   {
       $curl = curl_init();
      
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://waba.360dialog.io/v1/contacts",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => "{\n  \"blocking\": \"wait\",\n  \"contacts\": [\n   \"$contact\"\n  ],\n  \"force_check\": true\n}\n",
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json",
            "d360-api-key: $apikey",
            "postman-token: 9de2de14-0525-5dd1-97f6-b941a35c457e"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          return "cURL Error #:" . $err;
        } else {
          return $response;
        }
   }
   
   public function send_massages($arr,$apikey)
   {
       $curl = curl_init();
     
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://waba.360dialog.io/v1/messages",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $arr,
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json",
            "d360-api-key: $apikey",
            "postman-token: 4157bd19-eb68-dc0a-2337-592f12dff00b"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          return "cURL Error #:" . $err;
        } else {
          return $response;
        }
   }
  
}